# -*- coding: utf-8 -*-

TEXT_FORMATS = (
    ("html", "html"),
    ("markdown", "markdown"),
    ("plaintext", "plaintext")
)
