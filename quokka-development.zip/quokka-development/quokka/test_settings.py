# coding: utf-8

"""
This file is used for runtests.py or make test
"""
from quokka.settings import *  # flake8: noqa

MONGODB_DB = "quokka_test"
MODE = 'test'
DEBUG = False
DEBUG_TOOLBAR_ENABLED = False
