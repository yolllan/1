# coding: utf-8


# class MediaController(object):
#     """ A generic media controller to handle downlaods and uploads"""

#     @classmethod
#     def mass_upload(cls, method=None, filters=None, *args, **kwargs):
#         pass

#     def process_upload(self, method=None, *args, **kwargs):
#         pass

#     def process_download(self, *args, **kwargs):
#         pass

#     def upload_to_youtube(self, *args, **kwargs):
#         pass

#     def upload_to_vimeo(self, *args, **kwargs):
#         pass

#     def upload_to_dropbox(self, *args, **kwargs):
#         pass

#     def download_from_dropbox(self, *args, **kwargs):
#         pass

#     def upload_to_ftp(self, *args, **kwargs):
#         pass
