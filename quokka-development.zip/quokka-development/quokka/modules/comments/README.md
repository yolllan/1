quokka-comments
==================

# Quokka CommentsModule | Version 0.1.0

Decoupled comments

- http://github.com/pythonhub/quokka-media
-  by Bruno Rocha <rochacbruno@gmail.com>